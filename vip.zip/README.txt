athena ddos scripts were leaked by weird1337 t.me/ddospw


@YourAnonWriase is a scammer, do not do any transactions, he is the founder of athena ddos and athena hack.

script setups

    1  apt update && apt upgrade
    2  curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
    3  apt-get install nodejs -y
    5  ls
    7  chmod 777 *
    8  ls
    9  node httpddos.js
   10  npm install user-agents
   11  node httpddos.js
   12  npm install header-generator
   13  node httpddos.js
   14  npm install axios
   15  node httpddos.js
   16  node rapid.js

